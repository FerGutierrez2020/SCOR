from sys import argv
import subprocess

script=argv
name=str(script[0])
print ("Divirtiendonos un poco")

for i in range (0,60):
    directoryname='CARPETA'+str(i)
    subprocess.call(['mkdir',directoryname])
    subprocess.call(['cp',name,directoryname])