# -。- encoding = utf-8 -.-

#Implementación común del algoritmo: MD5： 128bits
#La longitud del MD5, el valor predeterminado es 128bit, que es una cadena de 128 0 y 1. 
#Esta expresión es muy extraño. Por lo tanto, se convierte en una base a base de 16, y cada uno de los 4 bits representa una base de 16
#Por lo que 128/4 = 32 se reemplaza con una representación de 16 enlace, es 32.


import hashlib

data = 'Ejemplo'

text = hashlib.md5()

text.update(data.encode())

print('MD5 Datos antes del cifrado:', data)
print('MD5 CRIPTED DATOS:', text.hexdigest())
print('MD5 Longitud cifrada:', len(text.hexdigest()))