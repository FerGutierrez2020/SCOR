import requests

url = "https://sandboxdnac.cisco.com/dna/system/api/v1/auth/token"

payload={}
headers = {
  'Authorization': 'Basic ZGV2bmV0dXNlcjpDaXNjbzEyMyE=',
  'Cookie': 'CP_GUTC=173.37.145.95.1590845878723833'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)